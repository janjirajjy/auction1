<!-- start form -->
<div class="container">
  <div class="row">
    <div class="col-xs-12 col-md-2"></div>
    <div class="col-xs-12 col-md-10">
      <form action="chklogin.php" method="post" class="form-horizontal">
        <div class="form-group">
          <div class="col-sm-2 control-label">
          </div>
          <div class="col-sm-4">
            <h3> :: FORM LOGIN::</h3>
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-2 control-label">
            Username :
          </div>
          <div class="col-sm-4">
            <input type="email" name="cus_email" required class="form-control" placeholder="*email">
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-2 control-label">
            Password :
          </div>
          <div class="col-sm-4">
            <input type="password" name="cus_password" required class="form-control" maxlength="10">
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-2">
          </div>
          <div class="col-sm-4">
            <button type="submit" class="btn btn-success">เข้าสู่ระบบ</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- end form -->