<?php 
include('header.php');
include('menu.php');
?>

<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="panel panel-info">
				<div class="panel-heading">
					<b> รายการชนะประมูล </b>
				</div>
			</div>
			<?php include('win_list.php');?>
		</div>
	</div>
</div>
<?php 
//include('list_prd.php');
include('footer.php');
?>
       
    
       

        