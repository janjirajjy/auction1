<h4> Form เพิ่มประเภทการส่ง </h4>
<form action="send_type_form_add_db.php" method="post" class="form-horizontal">
  <div class="form-group">
    <div class="col-sm-4 control-label">
      ชื่อประเภท :
    </div>
    <div class="col-sm-7">
      <input type="text" name="send_name" required class="form-control">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-4">
    </div>
    <div class="col-sm-1">
      <button type="submit" class="btn btn-success">บันทึก</button>
    </div>
  </div>
</form>