<div class="list-group" id="hd">
	<a href="index.php" class="list-group-item active">
		จัดการข้อมูลระบบ
	</a>
	<a href="user.php" class="list-group-item">-เจ้าของร้าน</a>
	<a href="customer.php" class="list-group-item">-สมาชิก</a>
	<a href="unit.php" class="list-group-item">-หน่วยสินค้า</a>
	<a href="product.php" class="list-group-item">-สินค้า</a>
	<a href="send_type.php" class="list-group-item">-ประเภทการส่ง</a>
	<a href="productstatus.php" class="list-group-item">-สถานะการจัดส่ง</a>
	<a href="bank.php" class="list-group-item">-ธนาคาร</a>
	<a href="../logout.php" class="list-group-item list-group-item-danger" onclick="return confirm('ยืนยัน');">ออกจากระบบ</a>
</div>