<!-- start footer -->
<div class="container-fluid">
  <div class="row">
    <div class="col-xs-12 col-md-12">
      <p align="center" style="margin: 100px">
       Backend Auction @2018
      </p>
    </div>
  </div>
</div>
<!-- end footer -->