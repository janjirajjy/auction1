<h4> Form เพิ่มหน่วยสินค้า </h4>
<form action="unit_form_add_db.php" method="post" class="form-horizontal">
  <div class="form-group">
    <div class="col-sm-4 control-label">
      ชื่อหน่วย :
    </div>
    <div class="col-sm-7">
      <input type="text" name="unit_detail" required class="form-control">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-4">
    </div>
    <div class="col-sm-1">
      <button type="submit" class="btn btn-success">บันทึก</button>
    </div>
  </div>
</form>