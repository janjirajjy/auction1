<h4> Form เพิ่มประเภทสินค้า </h4>
<form action="prdtype_form_add_db.php" method="post" class="form-horizontal">
  <div class="form-group">
    <div class="col-sm-4 control-label">
      ชื่อประเภทสินค้า :
    </div>
    <div class="col-sm-7">
      <input type="text" name="t_name" required class="form-control">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-4">
    </div>
    <div class="col-sm-1">
      <button type="submit" class="btn btn-primary">บันทึก</button>
    </div>
  </div>
</form>