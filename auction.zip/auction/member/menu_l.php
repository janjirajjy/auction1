<div class="list-group">
	<a href="index.php" class="list-group-item active">
		เมนูหลัก
	</a>
	<a href="profile.php" class="list-group-item">จัดการโปรไฟล์</a>
	<a href="bid.php" class="list-group-item">ประวัติการประมูล</a>
	<a href="../logout.php" class="list-group-item list-group-item-danger" onclick="return confirm('ยืนยัน');">ออกจากระบบ</a>
</div>